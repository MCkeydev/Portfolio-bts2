# MediaTek86

Vous pourrez retrouver dans le fichier PROJET1 les fichiers de l'application,
et le script complet de la BDD dans ScriptBDD.
