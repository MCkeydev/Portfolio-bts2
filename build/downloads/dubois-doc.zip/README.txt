La documentation technique de l'application est hébergée au lien suivant : https://quiz-doc.netlify.app

Une version locale se trouve dans le dossier "doc", il vous suffit de cliquer sur le fichier index.html