﻿/**
 * titre : calculs de dénombrements
 * description : permet 3 types de calculs (permutation, arrangement, combinaison)
 * auteur : Matthieu Courréjou
 * date création : 15/06/2020
 * date dernière modification : 15/11/2021
 */

using System;


namespace Denombrements
{
    class Program
    {
        /// <summary>
        /// Permet d'initialiser la variable string "choix"
        /// 
        /// </summary>
        /// <returns>string ""</returns>
        static string initChoix()
        {
            return "";
        }
        /// <summary>
        /// Permet de verifier si le choix est valide
        /// </summary>
        /// <param name="arg">Variable à soumettre au test de validité</param>
        /// <returns>un booleen</returns>
        static bool InvalidChoice(string arg)
        {
            if(arg != "0" && arg != "1" && arg != "2" && arg != "3") return true;
            else  return false; 
            
        }
        /// <summary>
        /// Fonction de gestion du menu et de contrôle de saisie
        /// </summary>
        /// <param name="choix">Variable choix</param>
        /// <returns>retourne le choix</returns>
        static string menu(string choix = "")
        {
            while(InvalidChoice(choix)) {
                
                    Console.WriteLine("Permutation ...................... 1");
                    Console.WriteLine("Arrangement ...................... 2");
                    Console.WriteLine("Combinaison ...................... 3");
                    Console.WriteLine("Quitter .......................... 0");
                    Console.Write("Choix :                            ");
                    choix = Console.ReadLine();
                if (InvalidChoice(choix))
                {
                    Console.WriteLine("saissez un choix valide !");
                }
            }
            return choix;
            

        }
      
        /// <summary>
        /// Menu permet de faire 3 types de calculs (permutation, arrangement, combinaison
        /// </summary>
        /// <param name="args"></param>
        static void Main(string[] args)
        {
            //Initialisation du choix
            string choix = initChoix();
            while (choix != "0")
            {
                choix = menu(choix);

                if (choix == "0") Environment.Exit(0);

                Console.Write("nombre total d'éléments à gérer = "); // le nombre d'éléments à gérer
                int nombre = int.Parse(Console.ReadLine()); // saisir le nombre

                if (choix == "1")
                {                                                                             
                    long r = 1;
                    for (int k = 1; k <= nombre; k++)
                    {
                        r *= k;
                    }
                    Console.WriteLine(nombre + "! = " + r);
                    choix = initChoix();
                }
                else
                {
                   
                    Console.Write("nombre d'éléments dans le sous ensemble = "); //saisir le sous ensemble
                    int sousEnsemble = int.Parse(Console.ReadLine()); 
                   
                    if (choix == "2")
                    {
                       // calcul de r
                        long resultat = 1;
                        for (int i = (nombre - sousEnsemble + 1); i <= nombre; i++)
                            resultat *= i;
                       //Calcul du resultat final
                        Console.WriteLine("A(" + nombre + "/" + sousEnsemble + ") = " + resultat);
                        choix = initChoix();
                    }
                    if (choix == "3")
                    {
                        // calcul de resulat1
                        long resultat1 = 1;
                        for (int i = (nombre - sousEnsemble + 1); i <= nombre; i++)
                            resultat1 *= i;

                        // calcul de resultat2
                        long resultat2 = 1;
                        for (int i = 1; i <= sousEnsemble; i++)
                            resultat2 *= i;
                        
                        //Calcul du resultat final
                        Console.WriteLine("C(" + nombre + "/" + sousEnsemble + ") = " + (resultat1 / resultat2));
                        choix = initChoix();
                    }
                    
                }
            }
            Console.ReadLine();
        }
    }
}
